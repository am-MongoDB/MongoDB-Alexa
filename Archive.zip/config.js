var config = {
	appId: "amzn1.ask.skill.0a271327-baf4-426c-a9c6-ee7d630c0deb",
	mongopopAPI: "http://clusterdb.myddns.me:3000/pop/"
};

module.exports = config;
