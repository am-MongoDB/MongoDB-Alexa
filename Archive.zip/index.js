"use strict";
var APP_ID = "amzn1.ask.skill.0a271327-baf4-426c-a9c6-ee7d630c0deb";  
var Alexa = require("alexa-sdk");

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;

    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    "AMAZON.HelpIntent": function () {
    this.emit(':tellWithCard',
        "Ask where Andrew is or ask how many times he has checked in",
        "Mongo – Where's Andrew",
        "Ask where Andrew is or ask how many times he has checked in",
        {
            smallImageUrl: "https://media.licdn.com/mpr/mpr/shrinknp_200_200/AAEAAQAAAAAAAALQAAAAJDhkZWUxZDQxLTM0NjctNDcxZS04NmJiLTA1YzRhNGVlNWY0ZQ.jpg",
            largeImageUrl: "https://media.licdn.com/mpr/mpr/shrinknp_200_200/AAEAAQAAAAAAAALQAAAAJDhkZWUxZDQxLTM0NjctNDcxZS04NmJiLTA1YzRhNGVlNWY0ZQ.jpg"
        }
    )}
};
